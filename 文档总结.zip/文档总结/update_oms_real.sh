#!/bin/sh

echo `date`
##########################greenplum############################
v_gp_db='bigdata'
v_gp_ip='10.7.5.16'
v_gp_u='gpadmin'
v_gp_port='5432'
###########################mysql###############################
v_mysql_db='datasupport'
v_mysql_ip='10.7.4.79'
v_mysql_u='root'
v_mysql_p='zt9YdPveyA9UDPKJGKJ'

v_id_str="SELECT id FROM md_table_conf WHERE db_id=10 AND is_all='add' AND STATUS=1"
v_tablename_str="SELECT table_name FROM md_table_conf WHERE db_id=10 AND is_all='add' AND STATUS=1"
id="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "${v_id_str}"`"
ids=($id)
unset ids[0]
echo ${ids[@]}
ids_num=${#ids[@]}
echo $ids_num
table_name="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "${v_tablename_str}"`"
table_names=($table_name)
unset table_names[0]
echo ${table_names[@]}
tablenames_num=${#table_names[@]}
echo $tablenames_num

for ((i=1;i<ids_num+1;i++)){
	id=${ids[i]}
	tablename=${table_names[i]}
	count_str="SELECT  count(*)FROM md_table_col_conf WHERE table_id=$id AND is_increase='Y';"
	echo $count_str
	count="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "${count_str}"`"
	count=`echo $count | cut -b 10-`
	echo $count
	if [ "$count" -eq "1" ]
	 then
		col_name_str="SELECT col_name FROM md_table_col_conf WHERE table_id=$id AND is_increase='Y'"
		echo $col_name_str
		col_name="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "${col_name_str}"`"
		col_name=`echo $col_name | cut -b 10-`
		echo $col_name
		max_date_str="select max($col_name) from src.src_oms_$tablename;"
		echo $max_date_str
		max_date="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${max_date_str}\\\"\" | sed -n '3p'`"
		max_datetime=`echo $max_date`
		if [ -n "$max_datetime" ]
		then
			echo $max_datetime
			update_str="update md_table_conf set column_value='$max_datetime' WHERE table_name='$tablename';"
			echo $update_str
			echo "不为空"
			update_maxdate="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "${update_str}"`"
			echo $update_maxdate
		else
			echo "maxdate 为空"
		fi
	 else
		echo "两个字段"
		twocol_name_str="SELECT col_name FROM md_table_col_conf WHERE table_id=$id AND is_increase='Y'"
		echo $twocol_name_str
		twocol_name="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "${twocol_name_str}"`"
		twocol_name=`echo $twocol_name`
		col_name_1=`echo $twocol_name | cut -d ' ' -f 2`
		col_name_2=`echo $twocol_name | cut -d ' ' -f 3`
		echo $col_name_1
		echo $col_name_2
		twomax_date_str="SELECT	CASE
WHEN MAX ($col_name_1::timestamp) >
	MAX ($col_name_2::timestamp)
	 THEN
	MAX ($col_name_1::timestamp)
ELSE
	MAX ($col_name_2::timestamp)
END create_time
FROM
	ods.ods_oms_$tablename;"
		echo $twomax_date_str
		twomax_date="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${twomax_date_str}\\\"\" | sed -n '3p'`"
		two_max_datetime=`echo $twomax_date`
		if [ -n "$two_max_datetime" ]
		then
			two_update_str="update md_table_conf set column_value='$two_max_datetime' WHERE table_name='$tablename';"
			echo $two_update_str
			echo "不为空"
			echo $two_max_datetime
			two_update_maxdate="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "${two_update_str}"`"
			echo $two_update_maxdate
		else
			echo "max_datetime 为空"
		fi 
	 fi
}
