#!/bin/sh
v_curday=`date +%Y%m%d`
v_curdayhour=`date +%Y%m%d%H`
v_15agoday=`date -d -5day +%Y%m%d`

if [ -d /uCloudlink/dumpdata/data_bak/oms/add/$v_curday/$v_curdayhour ];then
   rm -drf /uCloudlink/dumpdata/data_bak/oms/add/$v_curday/$v_curdayhour
   mkdir -p /uCloudlink/dumpdata/data_bak/oms/add/$v_curday/$v_curdayhour
   mv /data/dumpdata/metadata/add/oms  /uCloudlink/dumpdata/data_bak/oms/add/$v_curday/$v_curdayhour
else
   mkdir -p /uCloudlink/dumpdata/data_bak/oms/add/$v_curday/$v_curdayhour
   mv /data/dumpdata/metadata/add/oms  /uCloudlink/dumpdata/data_bak/oms/add/$v_curday/$v_curdayhour
fi

if [ -d /uCloudlink/dumpdata/data_bak/oms/add/$v_15agoday ];then
   rm -drf /uCloudlink/dumpdata/data_bak/oms/add/$v_15agoday
fi
mkdir -p /data/dumpdata/metadata/add/oms
