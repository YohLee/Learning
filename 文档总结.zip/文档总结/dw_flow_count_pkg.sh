#!/bin/sh
source /etc/profile

v_gp_db='bigdata'
v_gp_ip='10.7.5.16'
v_gp_u='gpadmin'
v_gp_port='5432'

now_day=$(date  +%Y-%m-%d )
echo $now_day
v_gp_str="select dw.dw_css_card_package_day('$now_day'::date);"
v_online_data_gp="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${v_gp_str}\\\"\"`"
v_online_data="$v_online_data_gp"

v_flow_count_str="select dw.dw_flow_count_package();"
v_flow_count_gp="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${v_flow_count_str}\\\"\"`"
v_flow_count="$v_flow_count_gp"

v_flow_use_str="select dw.dw_user_flow_use_statics_day('$now_day'::date);"
v_flow_use_gp="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${v_flow_use_str}\\\"\"`"
v_flow_use="$v_flow_use_gp"
