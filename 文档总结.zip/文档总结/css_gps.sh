#!/bin/sh

export JAVA_HOME=/usr/local/jdk8/jre
export PATH=$JAVA_HOME/bin:$PATH
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar

datetime=`date +%Y%m%d%H%M%S`
mkdir -p /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/logbak
mv /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/logbak/ETL_souredata_to_gp_ods_css_gps_${datetime}.log

echo "log has been copied!"
/root/data-integration/kitchen.sh -file=/data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.kjb >> /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log

cat /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | grep -a 'gpfdist' | sed '/External/d' | sed '/ERROR/d' | awk '{print $15}'| cut -d '/' -f 7 | cut -d '.' -f 1  > /root/check/css_gps/check_name


cat /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/file_css_gps.sh | cut -d '|' -f 3 | cut -d '>' -f 2 | cut -d '/' -f 7 | cut -d '.' -f 1 > /root/check/oms_real/table_real_name

#/data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | grep 'DUMP' | sed 's/try/exported 0/g' | grep 'exported' | sed '/\[/d' | awk '{print $20}' > /root/check/css_gps/check_dump

cat /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | grep -a 'gpload' | grep 'Inserted' | awk '{print $11}' > /root/check/css_gps/inserted_gpload

cat /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | grep -a 'gpload' | grep 'Updated' | awk '{print $11}' > /root/check/css_gps/updated_gpload

#/data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | grep -a 'DUMP' | grep '开始时间' | cut -d ')' -f 2 | cut -d '开' -f 2 | cut -b 11- > /root/check/css_gps/dump_starttime

#/data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | grep -a 'DUMP' | grep '结束时间' | cut -d ')' -f 2 | cut -d '结' -f 2 | cut -b 11- > /root/check/css_gps/dump_endtime

cat /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | grep -a 'gpload' | grep 'session' | sed '/encountered/d' | cut -d '|' -f 3 | cut -b 24- > /root/check/css_gps/gpload_starttime

cat /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | grep -a "gpload" | grep -E "succeeded|failed" | cut -d '|' -f 1 | cut -b 58- > /root/check/css_gps/gpload_endtime

cat /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | grep -a "gpload" | grep -E "succeeded|failed" | cut -d '|' -f 3 | cut -b 8- > /root/check/css_gps/status

paste -d "#" /root/check/css_gps/check_name /root/check/css_gps/table_real_name /root/check/css_gps/inserted_gpload /root/check/css_gps/updated_gpload /root/check/css_gps/gpload_starttime /root/check/css_gps/gpload_endtime /root/check/css_gps/status  > /root/check/css_gps/check_all

job_start_time=`grep -a "ETL_souredata_to_gp_ods_css_gps" /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | sed -n '1p' | awk -F '-' '{print $1}'`
job_end_time=`grep -a "ETL_souredata_to_gp_ods_css_gps" /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | sed -n '$p' | awk -F '-' '{print $1}'`

gpload_start_time=`grep -a "gpload_scp" /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | sed -n '1p' | awk -F '-' '{print $1}'`
gpload_end_time=`grep -a "gpload_yml.sh_exception -" /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | sed -n '$p' | awk -F '-' '{print $1}'`

dump_start_time=`grep -a "dump开始时间" /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | cut -d ')' -f 2 | cut -b 19-`
dump_end_time=`grep -a "dump结束时间" /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | cut -d ')' -f 2 | cut -b 19-`

remark=`more /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | grep "dump table cost"`

proc_start_time=`grep -a "css_gps_src2ods" /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | sed -n '1p' | awk -F '-' '{print $1}'`
proc_end_time=`grep -a "css_gps_src2ods" /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | sed -n '$p' | awk -F '-' '{print $1}'`

signal=`cat /data/04_ETL_souredata_to_gpdata_css_gps_encrypt/ETL_souredata_to_gp_ods_css_gps.log | grep -a 'src_to_ods' | grep -E '完成|Finished' | cut -d '(' -f 2 | cut -b 9-12`
echo $signal

###########################mysql###############################


v_mysql_db='datasupport'
v_mysql_ip='10.7.4.79'
v_mysql_u='root'
v_mysql_p='zt9YdPveyA9UDPKJGKJ'
job_name='ETL_souredata_to_gp_css_gps'
v_url_file='/root/check/css_gps/check_all'
v_date=`date +%Y-%m-%d`


job_cost_time="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "SELECT (UNIX_TIMESTAMP('$job_end_time') - UNIX_TIMESTAMP('$job_start_time')) sec"|sed -n '2p'`"
job_cost_time="$job_cost_time"

gpload_cost_time="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "SELECT (UNIX_TIMESTAMP('$gpload_end_time') - UNIX_TIMESTAMP('$gpload_start_time')) sec"|sed -n '2p'`"
gpload_cost_time="$gpload_cost_time"

dump_cost_time="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "SELECT (UNIX_TIMESTAMP('$dump_end_time') - UNIX_TIMESTAMP('$dump_start_time')) sec"|sed -n '2p'`"
dump_cost_time="$dump_cost_time"

proc_cost_time="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "SELECT (UNIX_TIMESTAMP('$proc_end_time') - UNIX_TIMESTAMP('$proc_start_time')) sec"|sed -n '2p'`"
proc_cost_time="$proc_cost_time"

##############################插入job_log表######################################
mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into job_log(job_name,begin_time,end_time,cost_time) values('$job_name','$job_start_time','$job_end_time','$job_cost_time');"
##############################获取job_log表最大id######################################
job_max_id="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "SELECT max(id) from job_log where job_name='$job_name'"|sed -n '2p'`"
job_max_id="$job_max_id"
##############################插入job_log_detail表######################################
mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into job_log_detail(job_log_id,step_id,step_name,begin_time,end_time,cost_time,remark) values(${job_max_id},1,'dump','$dump_start_time','$dump_end_time','$dump_cost_time','$remark');"
mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into job_log_detail(job_log_id,step_id,step_name,begin_time,end_time,cost_time) values(${job_max_id},2,'gpload','$gpload_start_time','$gpload_end_time','$gpload_cost_time');"
mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into job_log_detail(job_log_id,step_id,step_name,begin_time,end_time,cost_time,remark) values(${job_max_id},3,'src_to_ods','$proc_start_time','$proc_end_time','$proc_cost_time','$signal');"
##############################获取job_log_detail表最大id######################################
gpload_max_id="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "SELECT max(id) from job_log_detail where step_id=2 and job_log_id=${job_max_id};"|sed -n '2p'`"
gpload_max_id="$gpload_max_id"
dump_max_id="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "SELECT max(id) from job_log_detail where step_id=1 and job_log_id=${job_max_id};"|sed -n '2p'`"
dump_max_id="$dump_max_id"

##############################插入job_log_step_detail表######################################
cat $v_url_file | while read line
             do
                    table_name=`echo ${line} | awk -F# '{print $1}'`
                    table_real_name=`echo ${line} | awk -F# '{print $2}'`
                    inserted_gpload=`echo ${line} | awk -F# '{print $3}'`
					updated_gpload=`echo ${line} | awk -F# '{print $4}'`
					gpload=$((inserted_gpload+updated_gpload))
                    dump=$gpload
                    dump_starttime=$dump_start_time
                    dump_endtime=$dump_end_time
                    gpload_starttime=`echo ${line} | awk -F# '{print $5}'`
                    gpload_endtime=`echo ${line} | awk -F# '{print $6}'`
                    status=`echo ${line} | awk -F# '{print $7}'`

                                        ###gpload###
                    mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into job_log_step_detail(job_log_detail_id,table_name,table_real_name,deal_kind,record_count,begin_time,end_time,deal_status) values($gpload_max_id,'$table_name','$table_real_name','gpload',$gpload,'$gpload_starttime','$gpload_endtime','$status');"
                                        ###dump###
                    mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into job_log_step_detail(job_log_detail_id,table_name,table_real_name,deal_kind,record_count,begin_time,end_time,deal_status) values($dump_max_id,'$table_name','$table_real_name','dump',$dump,'$dump_starttime','$dump_endtime','$status');"
             done

if [ "$signal" == "true" ];
        then
                                        #####插入job任务状态,0失败,1成功
                    mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into t_job_task(job_name,task_desc,task_status,job_date) values('$job_name','css_gps_job',1,'$v_date');"

                    echo "success"
        else
                                    #####插入job任务状态,0失败,1成功
                                    mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into t_job_task(job_name,task_desc,task_status,job_date) values('$job_name','css_gps_job',0,'$v_date');"

                    echo "failed"
fi



