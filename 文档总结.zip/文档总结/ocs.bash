#!/bin/bash
source /etc/profile
date=`date +%Y%m%d`
echo $date
yesterday=`date -d"yesterday" +%Y%m%d`
echo $yesterday
tomorrow=`date -d"tomorrow" +%Y%m%d`
echo $tomorrow
today=`date +%Y%m%d`
echo $today
year=`date +%Y`
echo $year
month=`date +%m | sed s'/^0//'`
echo $month
day=`date +%d`
echo $day

#####################修改yml中的目的表#########
#today="flowdetail_${date}"
#sed -i "s/flowdetail_.*/flowdetail_${yesterday}/" /data/dumpdata/yml/ocs/flow.yml
###############################################

#####################计算昨日0点到今日0点时间戳
now_day=$(date  +%Y%m%d )
endDate=`expr $(date -d $now_day  +%s) \* 1000`
yestoday_day=$(date -d last-day  +%Y%m%d)
beginDate=`expr $(date -d $yestoday_day +%s) \* 1000`
echo $endDate
echo $beginDate
#########################################################




v_gp_db='bigdata'
v_gp_ip='10.7.5.16'
v_gp_u='gpadmin'
v_gp_port='5432'

#####################按天建表############################
#table_name="ods_flowdetail_${yesterday}"
#echo $table_name
#v_create_str="CREATE TABLE ods.${table_name}(
#_id varchar(50),
#flowId varchar(50),
#customerId varchar(50),
#imei varchar(100),
#sPayrel varchar(100),
#flowSize float8,
#pkgId varchar(50),
#upid varchar(50),
#ownerOrgId varchar(50),
#createDate float8,
#userName varchar(100),
#objOwerOrgId varchar(50),
#amount float8,
#afterAmount float8,
#visitCountry varchar(50),
#sessionId varchar(50),
#ownerMvnoId varchar(50),
#tradeType varchar(50),
#upstreamFlow float8,
#downFlow float8,
#imsi float8,
#mcc varchar(50),
#mnc varchar(50),
#lac varchar(50),
#cellId varchar(50),
#shouldDeducted float8,
#priceingPlanId varchar(50),
#assignCardId varchar(50),
#businessSizeUp float8,
#businessSizeDown float8,
#pkName varchar(100),
#startTime float8,
#endTime float8,
#mvnoCode varchar(50),
#orgCode varchar(50),
#pricingPlanName varchar(200),
#country varchar(50),
#province varchar(50),
#city varchar(50),
#payType varchar(255),
#logIds varchar(1000),
#orderTimeZone varchar(50),
#orderCreateDate float8,
#orderEndTime float8,
#orderStartTime float8
#)
#WITH (appendonly=true, compresslevel=5) DISTRIBUTED BY (_id) PARTITION BY LIST(mvnoCode)
#          (
#          PARTITION p_ods_flowdetail_DHI VALUES('DHI') WITH (tablename='ods_flowdetail_${yesterday}_prt_DHI', orientation=row , appendonly=true, compresslevel=5),
#          PARTITION p_ods_flowdetail_GLOBALWIFI VALUES('GLOBALWIFI') WITH (tablename='ods_flowdetail_${yesterday}_prt_GLOBALWIFI', orientation=row , appendonly=true, compresslevel=5),
#          PARTITION p_ods_flowdetail_GlocM VALUES('GlocM') WITH (tablename='ods_flowdetail_${yesterday}_prt_GlocM', orientation=row , appendonly=true, compresslevel=5),
#          PARTITION p_ods_flowdetail_JETFI VALUES('JETFI','KRCNK','TELESQUARE') WITH (tablename='ods_flowdetail-${yesterday}_prt_JETFI', orientation=row , appendonly=true, compresslevel=5),
#          PARTITION p_ods_flowdetail_VISONDATA VALUES('VISONDATA','U2CDomest','GlocalMeUS') WITH (tablename='ods_flowdetail_${yesterday}_prt_VISONDATA', orientation=row , appendonly=true, compresslevel=5),
#default partition other
#          );"
#is_table_exist="select tablename from pg_tables WHERE  tablename = '${table_name}'"
#echo $is_table_exist
#is_table_exist_result="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${is_table_exist}\\\"\" | sed -n '3p'`"
#echo $is_table_exist_result
#
#if [ "`echo $is_table_exist_result`" = "$table_name" ];
#then
#        drop_table="drop table ods.${table_name}"
#        echo $drop_table
#        drop_table_result="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${drop_table}\\\"\"`"
#        echo $drop_table_result
#        echo $v_create_str
#        v_create_result="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${v_create_str}\\\"\"`"
#        echo $v_create_result
#else
#                echo $v_create_str
#                v_create_result="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${v_create_str}\\\"\"`"
#                echo $v_create_result
#fi

#########################################################

#####################读取mvno code#######################
v_code_str="SELECT code from ods.ods_bss_crm_mvno WHERE state='enable' AND isdeleted='f';"
v_code_name="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${v_code_str}\\\"\" | cut -d '(' -f 1 `"
echo $v_code_name
arr=($v_code_name)
unset arr[0]
unset arr[1]
#########################################################
v_curday=`date +%Y%m%d`
v_curdayhour=`date +%Y%m%d%H`
v_15agoday=`date -d -5day +%Y%m%d`

if [ -d /uCloudlink/dumpdata/data_bak/ocs/add/$v_curday/$v_curdayhour ];then
   rm -drf /uCloudlink/dumpdata/data_bak/ocs/add/$v_curday/$v_curdayhour
   mkdir -p /uCloudlink/dumpdata/data_bak/ocs/add/$v_curday/$v_curdayhour
   mv /data/dumpdata/metadata/add/ocs  /uCloudlink/dumpdata/data_bak/ocs/add/$v_curday/$v_curdayhour
else
   mkdir -p /uCloudlink/dumpdata/data_bak/ocs/add/$v_curday/$v_curdayhour
   mv /data/dumpdata/metadata/add/ocs  /uCloudlink/dumpdata/data_bak/ocs/add/$v_curday/$v_curdayhour
fi

if [ -d /uCloudlink/dumpdata/data_bak/ocs/add/$v_15agoday ];then
   rm -drf /uCloudlink/dumpdata/data_bak/ocs/add/$v_15agoday
fi
mkdir -p /data/dumpdata/metadata/add/ocs
#######################清空src层数据####################
v_truncate_str="truncate table src.src_ocs_flowdetail"
v_truncate="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${v_truncate_str}\\\"\"`"
#########################增加分区#####################
partition_yesterday_startdate=`date -d"yesterday" +%Y-%m-%d`
partition_yesterday_enddate=`date +%Y-%m-%d`
partition_today_startdate=`date +%Y-%m-%d`
partition_today_enddate=`date -d"tomorrow" +%Y-%m-%d`
is_partition_yesterday_exist="select 1 from pg_partitions WHERE  tablename = 'ods_ocs_flowdetail' and partitionname='ods_ocs_flowdetail_p${yesterday}'"
is_partition_yesterday_exist_result="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${is_partition_yesterday_exist}\\\"\" | sed -n '3p'`"
is_partition_today_exist="select 1 from pg_partitions WHERE  tablename = 'ods_ocs_flowdetail' and partitionname='ods_ocs_flowdetail_p${today}'"
is_partition_today_exist_result="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${is_partition_today_exist}\\\"\" | sed -n '3p'`"
if [ "`echo $is_partition_yesterday_exist_result`" -eq "1" ];
then
        echo "昨天的分区已经存在"
else
        create_partion_yesterday_str="ALTER TABLE ods.ods_ocs_flowdetail ADD PARTITION ods_ocs_flowdetail_p${yesterday} START ('${partition_yesterday_startdate}'::date) END ('${partition_yesterday_enddate}'::date) WITH (tablename='ods_ocs_flowdetail_p${yesterday}', orientation=row ,appendonly=true,compresslevel=5);"
        create_partition="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${create_partion_yesterday_str}\\\"\"`"
        echo "昨天的分区创建成功"
fi

if [ "`echo $is_partition_today_exist_result`" -eq "1" ];
then
        echo "今天的分区已经存在"
else
        create_partion_today_str="ALTER TABLE ods.ods_ocs_flowdetail ADD PARTITION ods_ocs_flowdetail_p${today} START ('${partition_today_startdate}'::date) END ('${partition_today_enddate}'::date) WITH (tablename='ods_ocs_flowdetail_p${today}', orientation=row ,appendonly=true,compresslevel=5);"
        create_partition="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${create_partion_today_str}\\\"\"`"
        echo "今天的分区创建成功"
fi

#######################循环执行dump和gpload##############
for i in ${arr[@]}
        do
                echo $i
                #v_dump_str="/uCloudlink/mongodb3011/bin/mongoexport  -h 10.7.19.25 --port 27019 -u xian_query -p DJyBjiyJu2018 -d bss -c FLOW_${i}_${year}_${month} -f _id,flowId,customerId,imei,sPayrel,flowSize,pkgId,upid,ownerOrgId,createDate,userName,objOwerOrgId,amount,afterAmount,visitCountry,sessionId,ownerMvnoId,tradeType,upstreamFlow,downFlow,imsi,mcc,mnc,lac,cellId,shouldDeducted,priceingPlanId,assignCardId,businessSizeUp,businessSizeDown,pkName,startTime,endTime,mvnoCode,orgCode,pricingPlanName,country,province,city,payType,logIds,orderTimeZone,orderCreateDate,orderEndTime,orderStartTime -q '{"createDate":{"\$gte":${beginDate},"\$lte":${endDate}}}' --type=csv -o /data/dumpdata/metadata/add/ocs/FLOW_${i}.csv"
                v_dump_str="/uCloudlink/mongodb3011/bin/mongoexport  -h 10.7.19.25 --port 27019 -u xian_query -p DJyBjiyJu2018 -d bss -c FLOW_${i}_${year}_${month} -f _id,accountId,accountType,flowId,customerId,imei,sPayrel,flowSize,pkgId,upid,ownerOrgId,createDate,userName,objOwerOrgId,amount,afterAmount,visitCountry,sessionId,ownerMvnoId,tradeType,upstreamFlow,downFlow,imsi,mcc,mnc,lac,cellId,shouldDeducted,priceingPlanId,assignCardId,businessSizeUp,businessSizeDown,pkName,startTime,endTime,mvnoCode,orgCode,pricingPlanName,country,province,city,payType,logIds,orderTimeZone,orderCreateDate,orderEndTime,orderStartTime,createCustId,flowSizeAfter,isSuccess,objAccountId,objCustomerId,objUserName,pricingParagraphId,pricingParagraphName,pricingStrategyId,pricingStrategyName,processState,processTime,rate,serialNumbere,excuteendtime,excuteday -q '{"createDate":{"\$gte":${beginDate},"\$lte":${endDate}}}' --type=csv -o /data/dumpdata/metadata/add/ocs/FLOW_${i}.csv"           
                v_gpload_str="gpload -f /data/dumpdata/yml/ocs/flow.yml"
                sed -i "s/FLOW_.*/FLOW_${i}.csv/" /data/dumpdata/yml/ocs/flow.yml
                echo $v_dump_str
                eval $v_dump_str
                echo $v_gpload_str
                eval $v_gpload_str
        done
###########################src_to_ods########################
src_to_ods_str="insert into ods.ods_ocs_flowdetail(_id,accountid,accounttype,flowid,customerid,imei,spayrel,flowsize,pkgid,upid,ownerorgid,createdate,username,objowerorgid,amount,afteramount,visitcountry,sessionid,ownermvnoid,tradetype,upstreamflow,downflow,imsi,mcc,mnc,lac,cellid,shoulddeducted,priceingplanid,assigncardid,businesssizeup,businesssizedown,pkname,starttime,endtime,mvnocode,orgcode,pricingplanname,country,province,city,paytype,logids,ordertimezone,ordercreatedate,orderendtime,orderstarttime,createcustid,flowsizeafter,issuccess,objaccountid,objcustomerid,objusername,pricingparagraphid,pricingparagraphname,pricingstrategyid,pricingstrategyname,processstate,processtime,rate,serialnumbere,excuteendtime,excuteday,createtime)select _id,accountid,accounttype,flowid,customerid,imei,spayrel,flowsize,pkgid,upid,ownerorgid,createdate,username,objowerorgid,amount,afteramount,visitcountry,sessionid,ownermvnoid,tradetype,upstreamflow,downflow,imsi,mcc,mnc,lac,cellid,shoulddeducted,priceingplanid,assigncardid,businesssizeup,businesssizedown,pkname,starttime,endtime,mvnocode,orgcode,pricingplanname,country,province,city,paytype,logids,ordertimezone,ordercreatedate,orderendtime,orderstarttime,createcustid,flowsizeafter,issuccess,objaccountid,objcustomerid,objusername,pricingparagraphid,pricingparagraphname,pricingstrategyid,pricingstrategyname,processstate,processtime,rate,serialnumbere,excuteendtime,excuteday,to_timestamp(createdate / 1000)::date from src.src_ocs_flowdetail;"
src_to_ods="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${src_to_ods_str}\\\"\"`"
echo "success"