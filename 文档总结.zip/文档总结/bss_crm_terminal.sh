#!/bin/bash

source /etc/profile
        ####################################################mysql_datasupport###############################################
        v_mysql_db='datasupport'
        v_mysql_ip='10.7.4.79'
        v_mysql_u='root'
        v_mysql_p='zt9YdPveyA9UDPKJGKJ'
	v_date=`date +%Y-%m-%d`
        job_name='bss_crm_terminal'


        ##############################################Terminal###########################################################
        v_datestamp=`date +%Y%m%d%H%M%S`
        echo "开始时间:"$v_datestamp

        if [ -f "/data/dumpdata/metadata/add/interval_job/Terminal.csv" ];then
                        mv /data/dumpdata/metadata/add/interval_job/Terminal.csv /uCloudlink/dumpdata/data_bak/css/interval_bak/Terminal_$v_datestamp.csv
        fi

        find /uCloudlink/dumpdata/data_bak/css/interval_bak -mtime +1 -name "*.*" -exec rm -rf {} \;

        v_datetime=`date -d today +"%Y-%m-%d %T"`
        echo "Terminal开始时间:"$v_datetime
        #v_Terminal="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e \"SELECT last_timestamp FROM t_interval_job WHERE interval_time=1 AND jobstatus=1 AND database_kind='mongodb' AND table_name='Terminal';\" | sed '1d'`"
        #echo $v_Terminal

        #/uCloudlink/mongodb3011/bin/mongoexport  -h 10.7.3.33 --port 27019 -u xianquery -p DKyB2e95xian -d bss -c Terminal -f _id,code,createTime,creatorId,creatorMvnoId,creatorMvnoName,creatorName,creatorOrgId,creatorOrgName,firstActivateTime,hardVersion,imei,isDeleted,modifyDate,mvnoId,mvnoName,name,orgId,orgName,ownerType,password,seedIccid,softVersion,state,type,description,mgmtUrl,seedImsi,qrcodeUrl  --type=csv -o /data/dumpdata/metadata/add/interval_job/Terminal.csv

        v_mongo="/uCloudlink/mongodb3011/bin/mongoexport  -h 10.7.3.33 --port 27019 -u xianquery -p DKyB2e95xian -d bss -c Terminal -f _id,code,createTime,creatorId,creatorMvnoId,creatorMvnoName,creatorName,creatorOrgId,creatorOrgName,firstActivateTime,hardVersion,imei,isDeleted,modifyDate,mvnoId,mvnoName,name,orgId,orgName,ownerType,password,seedIccid,softVersion,state,type,description,mgmtUrl,seedImsi,qrcodeUrl --type=csv -o /data/dumpdata/metadata/add/interval_job/Terminal.csv"
        echo $v_mongo
        eval $v_mongo

        gpload -f /data/dumpdata/metadata/add/interval_job/bss_crm_Terminal.yml


       ## ##############################################获取src层最大时间并更新配置表##########################################
       ## v_gp_db='bigdata'
       ## v_gp_ip='10.7.5.16'
       ## v_gp_u='gpadmin'
       ## v_gp_port='5432'
       ##
       ##
       ## v_table_str="SELECT table_name FROM t_interval_job WHERE interval_time=1 AND jobstatus=1 AND database_kind='mongodb';"
       ## v_table_name="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e \"${v_table_str}\"`"
       ## echo $v_table_name
       ##
       ## OLD_IFS="$IFS"              #IFS : Internal Field Separator，默认值为空格/tab/新行
       ## IFS=","                     #将IFS临时替换为","
       ## arr=($v_table_name)
       ## IFS="$OLD_IFS"              #将 IFS 替换回去
       ## for i in ${arr[@]}
       ##
       ## do
       ##                 if [ "$i" != "table_name" ];then
       ##                                 v_get_value=`eval echo '$'v_${i}`
       ##                                 echo $v_get_value
       ##                                 v_gp_str="select case when max(createtime)>coalesce(max(modifydate),963360000000) then max(createtime) else max(modifydate) end create_time from ods.ods_bss_crm_$i where createtime >'$v_get_value' or modifydate > '$v_get_value';"
       ##
       ##                                 echo "获取查询语句:$v_gp_str"
       ##                                 v_last_time="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${v_gp_str}\\\"\" | sed -n '3p' | xargs echo`"
       ##                                 echo "v_last_time:$v_last_time"
       ##                                 v_datetime=`date -d today +"%Y-%m-%d %T"`
       ##
       ##                                 if [ -n "$v_last_time" ] ; then
       ##                                                                 echo $i":表数据更新"
       ##                                                                 v_update_time="UPDATE t_interval_job SET last_timestamp='${v_last_time}',updatetime='${v_datetime}' WHERE table_name='$i';"
       ##                                                                 echo "更新语句：$v_update_time"
       ##                                                                 mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "${v_update_time}"
       ##                                                                 echo "Update last_timestamp"
       ##                                 fi
       ##                 fi
       ## done
       ##
       ## ########################################greenplum 第五步调用src_ods存错过程############################################
       ## #v_gp_stored="SELECT ods.ods_css_src2ods_real();"
       ## #v_gp_stored_execute="`su - gpadmin -c \"psql -h ${v_gp_ip} -p ${v_gp_port} -U ${v_gp_u} -d ${v_gp_db} -c \\\"${v_gp_stored}\\\"\" | sed -n '3p'`"
       ## #v_gp_stored_t_interval_job="$v_gp_stored_execute"
       ## #echo $v_gp_stored_t_interval_job
       ##
        v_datestamp_end=`date +%Y%m%d%H%M%S`
        echo "结束时间:"$v_datestamp_end
	mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into t_job_task(job_name,task_desc,task_status,job_date) values('$job_name','bss_crm_terminal_job',1,'$v_date');"
