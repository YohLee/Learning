#!/bin/sh

source /etc/profile

datetime=`date +%Y%m%d%H%M%S`
mkdir -p /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/logbak
mv /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/logbak/ETL_souredata_to_gp_ods_oss_perflog_${datetime}.log

echo "log has been copied!"

/root/data-integration/kitchen.sh -file=/data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.kjb>>/data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log


cat /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | grep 'gpfdist' | sed '/External/d' | sed '/ERROR/d' | awk '{print $15}'| cut -d '/' -f 7 | cut -d '.' -f 1  > /root/check/oss_perflog/check_perflog_name

cat /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/file_oss_perflog.sh | cut -d ' ' -f 14 > /root/check/oss_perflog/table_real_perflog_name

#cat /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | grep 'DUMP' | sed 's/try/exported -1/g' | grep 'exported' | sed '/\[/d' | awk '{print $20}' > /root/check/oss_perflog/check_perflog_dump

cat /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | grep 'gpload' | grep 'Inserted' | awk '{print $11}' > /root/check/oss_perflog/check_perflog_gpload

#cat /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | grep 'DUMP' | sed 's/try/exported 0/g' | sed 's/error/connected/g' | grep 'connected' | sed '/\[/d' | awk -F- '{print $1 }' > /root/check/oss_perflog/dump_perflog_starttime

#cat /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | grep 'DUMP' | sed 's/try/exported 0/g' | sed 's/error/connected/g' | grep 'exported' | sed '/\[/d' | awk -F- '{print $1 }' > /root/check/oss_perflog/dump_perflog_endtime

cat /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | grep 'gpload' | grep 'session' | sed '/encountered/d' | cut -d '|' -f 3 | cut -b 24- > /root/check/oss_perflog/gpload_perflog_starttime

cat /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | grep "gpload" | grep -E "succeeded|failed" | cut -d '|' -f 1 | cut -b 58- > /root/check/oss_perflog/gpload_perflog_endtime

cat /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | grep "gpload" | grep -E "succeeded|failed" | cut -d '|' -f 3 | cut -b 8- > /root/check/oss_perflog/perflog_status

paste -d "#" /root/check/oss_perflog/check_perflog_name /root/check/oss_perflog/table_real_perflog_name /root/check/oss_perflog/check_perflog_dump /root/check/oss_perflog/check_perflog_gpload /root/check/oss_perflog/dump_perflog_starttime /root/check/oss_perflog/dump_perflog_endtime /root/check/oss_perflog/gpload_perflog_starttime  /root/check/oss_perflog/gpload_perflog_endtime /root/check/oss_perflog/perflog_status  > /root/check/oss_perflog/check_all

job_start_time=`grep -a "ETL_souredata_to_gp_ods_oss_perflog" /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | sed -n '1p' | awk -F '-' '{print $1}'`
job_end_time=`grep -a "ETL_souredata_to_gp_ods_oss_perflog" /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | sed -n '$p' | awk -F '-' '{print $1}'`

gpload_start_time=`grep -a "gpload_scp" /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | sed -n '1p' | awk -F '-' '{print $1}'`
gpload_end_time=`grep -a "gpload_yml.sh_exception -" /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | sed -n '$p' | awk -F '-' '{print $1}'`


dump_start_time=`grep -a "dump开始时间" /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | sed -n '1p' | awk -F '-' '{print $1}'`
dump_end_time=`grep -a "dump结束时间" /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | sed -n '$p' | awk -F '-' '{print $1}'`


remark=`more /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | grep "dump table cost"`

proc_start_time=`grep -a "oss_perflog_src2ods" /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | sed -n '1p' | awk -F '-' '{print $1}'`
proc_end_time=`grep -a "oss_perflog_src2ods" /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | sed -n '$p' | awk -F '-' '{print $1}'`


signal=`cat /data/04_ETL_souredata_to_gpdata_oss_perflog_encrypt/ETL_souredata_to_gp_ods_oss_perflog.log | grep 'src_to_ods' | grep -E '完成|Finished' | cut -d '(' -f 2 | cut -b 9-12`
echo $signal

###########################mysql###############################


v_mysql_db='datasupport'
v_mysql_ip='10.7.4.79'
v_mysql_u='root'
v_mysql_p='zt9YdPveyA9UDPKJGKJ'
job_name='ETL_souredata_to_gp_oss_perflog'
v_url_file='/root/check/oss_perflog/check_all'
v_date=`date +%Y-%m-%d`


job_cost_time="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "SELECT (UNIX_TIMESTAMP('$job_end_time') - UNIX_TIMESTAMP('$job_start_time')) sec"|sed -n '2p'`"
job_cost_time="$job_cost_time"

gpload_cost_time="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "SELECT (UNIX_TIMESTAMP('$gpload_end_time') - UNIX_TIMESTAMP('$gpload_start_time')) sec"|sed -n '2p'`"
gpload_cost_time="$gpload_cost_time"

dump_cost_time="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "SELECT (UNIX_TIMESTAMP('$dump_end_time') - UNIX_TIMESTAMP('$dump_start_time')) sec"|sed -n '2p'`"
dump_cost_time="$dump_cost_time"

proc_cost_time="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "SELECT (UNIX_TIMESTAMP('$proc_end_time') - UNIX_TIMESTAMP('$proc_start_time')) sec"|sed -n '2p'`"
proc_cost_time="$proc_cost_time"

##############################插入job_log表######################################
mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into job_log(job_name,begin_time,end_time,cost_time) values('$job_name','$job_start_time','$job_end_time','$job_cost_time');"
##############################获取job_log表最大id######################################
job_max_id="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "SELECT max(id) from job_log where job_name='$job_name'"|sed -n '2p'`"
job_max_id="$job_max_id"
##############################插入job_log_detail表######################################
mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into job_log_detail(job_log_id,step_id,step_name,begin_time,end_time,cost_time,remark) values(${job_max_id},1,'dump','$dump_start_time','$dump_end_time','$dump_cost_time','$remark');"
mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into job_log_detail(job_log_id,step_id,step_name,begin_time,end_time,cost_time) values(${job_max_id},2,'gpload','$gpload_start_time','$gpload_end_time','$gpload_cost_time');"
mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into job_log_detail(job_log_id,step_id,step_name,begin_time,end_time,cost_time,remark) values(${job_max_id},3,'src_to_ods','$proc_start_time','$proc_end_time','$proc_cost_time','$signal');"
##############################获取job_log_detail表最大id######################################
gpload_max_id="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "SELECT max(id) from job_log_detail where step_id=2 and job_log_id=${job_max_id};"|sed -n '2p'`"
gpload_max_id="$gpload_max_id"
dump_max_id="`mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "SELECT max(id) from job_log_detail where step_id=1 and job_log_id=${job_max_id};"|sed -n '2p'`"
dump_max_id="$dump_max_id"
##############################插入job_log_step_detail表######################################

cat $v_url_file | while read line
             do
                    table_name=`echo ${line} | awk -F# '{print $1}'`
                    table_real_name=`echo ${line} | awk -F# '{print $2}'`
                    #dump=`echo ${line} | awk -F# '{print $3}'`
                    gpload=`echo ${line} | awk -F# '{print $4}'`
                    #dump_starttime=`echo ${line} | awk -F# '{print $5}'`
                    #dump_endtime=`echo ${line} | awk -F# '{print $6}'`
                    gpload_starttime=`echo ${line} | awk -F# '{print $7}'`
                    gpload_endtime=`echo ${line} | awk -F# '{print $8}'`
		    dump=$gpload
                    dump_starttime=$dump_start_time
                    dump_endtime=$dump_end_time
                    status=`echo ${line} | awk -F# '{print $9}'`
                                        if [ "${dump}" -gt "-1" ];
                                                then
                                                        dump_status='succeeded'
                                                else 
                                                        dump_status='failed'
                    fi

                                        ###gpload###
                    mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into job_log_step_detail(job_log_detail_id,table_name,table_real_name,deal_kind,record_count,begin_time,end_time,deal_status) values($gpload_max_id,'$table_name','$table_real_name','gpload',$gpload,'$gpload_starttime','$gpload_endtime','$status');"
                                        ###dump###
                    mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into job_log_step_detail(job_log_detail_id,table_name,table_real_name,deal_kind,record_count,begin_time,end_time,deal_status) values($dump_max_id,'$table_name','$table_real_name','dump',$dump,'$dump_starttime','$dump_endtime','$dump_status');"
             done

if [ "$signal" == "true" ];
        then
                                        #####插入job任务状态,0失败,1成功
                    mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into t_job_task(job_name,task_desc,task_status,job_date) values('$job_name','oss_perflog按天job',1,'$v_date');"

                    echo "success"
        else
                                    #####插入job任务状态,0失败,1成功
                                    mysql -A ${v_mysql_db} -h ${v_mysql_ip} -u${v_mysql_u} -p${v_mysql_p} -e "insert into t_job_task(job_name,task_desc,task_status,job_date) values('$job_name','oss_perflog按天job',0,'$v_date');"

                    echo "failed"
fi
